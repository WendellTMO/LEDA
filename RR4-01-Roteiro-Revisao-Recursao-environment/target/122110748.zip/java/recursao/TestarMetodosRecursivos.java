package recursao;

public class TestarMetodosRecursivos {
	public static void main(String[] args) {
		// preencha esse metodo com codigo para testar a classe MetodosRecursivos.
		int[] ar = {1,2,3,4,5,6,7,8,9};
		MetodosRecursivos m = new MetodosRecursivos();
		System.out.println(m.calcularSomaArray(ar));

	}
}
